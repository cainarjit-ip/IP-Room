export interface ProvinceData {
  id: number;
  nameEn: string;
  nameNp: string;
  districts: DistrictData[];
}

export interface DistrictData {
  nameEn: string;
  nameNp: string;
  municipalities: MunicipalityData[];
}

export interface MunicipalityData {
  nameEn: string;
  nameNp: string;
  type: 'Metro' | 'Sub-Metro' | 'Municipality';
  wards: number[];
  popularAreas: string[];
}

export interface CampusMarker {
  nameEn: string;
  nameNp: string;
  city: string;
  district: string;
  lat: number;
  lng: number;
  studentsCount: string;
}

export const NEPAL_PROVINCES: ProvinceData[] = [
  {
    id: 3,
    nameEn: 'Bagmati Province',
    nameNp: 'बागमती प्रदेश',
    districts: [
      {
        nameEn: 'Kathmandu',
        nameNp: 'काठमाडौँ',
        municipalities: [
          {
            nameEn: 'Kathmandu Metropolitan City',
            nameNp: 'काठमाडौँ महानगरपालिका',
            type: 'Metro',
            wards: [1, 2, 3, 4, 7, 10, 16, 26, 28, 29, 30, 31, 32],
            popularAreas: ['New Baneshwor', 'Putalisadak', 'Bagbazar', 'Maitighar', 'Thamel', 'Baluwatar', 'Kapan', 'Chabahil', 'Samakhusi', 'Kalanki']
          },
          {
            nameEn: 'Kirtipur Municipality',
            nameNp: 'कीर्तिपुर नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            popularAreas: ['TU Gate', 'Nayabazar Kirtipur', 'Chhobar', 'Panga', 'Baghbhairab']
          },
          {
            nameEn: 'Budhanilkantha Municipality',
            nameNp: 'बुढानीलकण्ठ नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 4, 5, 8, 10],
            popularAreas: ['Golfutar', 'Hattigauda', 'Chunikhel', 'Mandikhatar']
          },
          {
            nameEn: 'Tokha Municipality',
            nameNp: 'टोखा नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 5, 6, 7],
            popularAreas: ['Dhapasi', 'Basundhara', 'Grande Area', 'Tokha Road']
          }
        ]
      },
      {
        nameEn: 'Lalitpur',
        nameNp: 'ललितपुर',
        municipalities: [
          {
            nameEn: 'Lalitpur Metropolitan City',
            nameNp: 'ललितपुर महानगरपालिका',
            type: 'Metro',
            wards: [1, 2, 3, 4, 5, 9, 14, 15, 19, 20],
            popularAreas: ['Pulchowk', 'Patan Dhoka', 'Sanepa', 'Kupondole', 'Balkumari', 'Jawalakhel', 'Kumaripati', 'Lagankhel', 'Gwarko']
          },
          {
            nameEn: 'Mahalaxmi Municipality',
            nameNp: 'महालक्ष्मी नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 4, 5],
            popularAreas: ['Imadol', 'Tikathali', 'Lubhu', 'Sanagaun']
          }
        ]
      },
      {
        nameEn: 'Bhaktapur',
        nameNp: 'भक्तपुर',
        municipalities: [
          {
            nameEn: 'Bhaktapur Municipality',
            nameNp: 'भक्तपुर नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            popularAreas: ['Dudhpati', 'Suryabinayak', 'Durbar Square area', 'Kamalbinayak']
          },
          {
            nameEn: 'Madhyapur Thimi Municipality',
            nameNp: 'मध्यपुर थिमी नगरपालिका',
            type: 'Municipality',
            wards: [1, 2, 3, 4, 5, 6],
            popularAreas: ['Sano Thimi', 'Lokanthali', 'Gatthaghar', 'Kaushaltar']
          }
        ]
      },
      {
        nameEn: 'Chitwan',
        nameNp: 'चितवन',
        municipalities: [
          {
            nameEn: 'Bharatpur Metropolitan City',
            nameNp: 'भरतपुर महानगरपालिका',
            type: 'Metro',
            wards: [1, 2, 4, 7, 10, 11, 12],
            popularAreas: ['Chaubiskothi', 'CMC Medical College', 'Lions Chowk', 'Birendra Campus area', 'Narayangarh']
          }
        ]
      }
    ]
  },
  {
    id: 4,
    nameEn: 'Gandaki Province',
    nameNp: 'गण्डकी प्रदेश',
    districts: [
      {
        nameEn: 'Kaski',
        nameNp: 'कास्की',
        municipalities: [
          {
            nameEn: 'Pokhara Metropolitan City',
            nameNp: 'पोखरा महानगरपालिका',
            type: 'Metro',
            wards: [1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 17],
            popularAreas: ['Lakeside', 'Bagar (PN Campus)', 'Zero KM', 'Prithvi Chowk', 'Srijana Chowk', 'Lamachaur (WRC Engg)', 'Nadipur', 'Parsyang']
          }
        ]
      }
    ]
  },
  {
    id: 1,
    nameEn: 'Koshi Province',
    nameNp: 'कोशी प्रदेश',
    districts: [
      {
        nameEn: 'Morang',
        nameNp: 'मोरङ',
        municipalities: [
          {
            nameEn: 'Biratnagar Metropolitan City',
            nameNp: 'विराटनगर महानगरपालिका',
            type: 'Metro',
            wards: [1, 2, 3, 4, 7, 10, 11],
            popularAreas: ['Traffic Chowk', 'Main Road', 'Kanchanbari', 'Hospital Chowk', 'Purbanchal University Area']
          }
        ]
      },
      {
        nameEn: 'Sunsari',
        nameNp: 'सुनसरी',
        municipalities: [
          {
            nameEn: 'Dharan Sub-Metropolitan City',
            nameNp: 'धरान उपमहानगरपालिका',
            type: 'Sub-Metro',
            wards: [1, 3, 8, 12, 16],
            popularAreas: ['BPKIHS Area', 'Bhanu Chowk', 'Pindeshwor', 'Bijayapur']
          }
        ]
      }
    ]
  },
  {
    id: 5,
    nameEn: 'Lumbini Province',
    nameNp: 'लुम्बिनी प्रदेश',
    districts: [
      {
        nameEn: 'Rupandehi',
        nameNp: 'रुपन्देही',
        municipalities: [
          {
            nameEn: 'Butwal Sub-Metropolitan City',
            nameNp: 'बुटवल उपमहानगरपालिका',
            type: 'Sub-Metro',
            wards: [1, 4, 6, 8, 11],
            popularAreas: ['Traffic Chowk', 'Golpark', 'Kalikanagar', 'Milanchowk', 'Deepnagar']
          }
        ]
      }
    ]
  }
];

export const NEPAL_CAMPUSES: CampusMarker[] = [
  {
    nameEn: 'Tribhuvan University (Central Campus)',
    nameNp: 'त्रिभुवन विश्वविद्यालय (केन्द्रीय क्याम्पस)',
    city: 'Kirtipur, Kathmandu',
    district: 'Kathmandu',
    lat: 27.6792,
    lng: 85.2894,
    studentsCount: '35,000+ Students'
  },
  {
    nameEn: 'Pulchowk Campus (IOE)',
    nameNp: 'पुल्चोक इन्जिनियरिङ क्याम्पस',
    city: 'Pulchowk, Lalitpur',
    district: 'Lalitpur',
    lat: 27.6798,
    lng: 85.3175,
    studentsCount: '4,000+ Engineers'
  },
  {
    nameEn: 'Shankar Dev Campus',
    nameNp: 'शंकरदेव क्याम्पस',
    city: 'Putalisadak, Kathmandu',
    district: 'Kathmandu',
    lat: 27.7056,
    lng: 85.3218,
    studentsCount: '9,000+ Management'
  },
  {
    nameEn: 'Apex College / Baneshwor Colleges',
    nameNp: 'एपेक्स कलेज / नयाँ बानेश्वर',
    city: 'New Baneshwor, Kathmandu',
    district: 'Kathmandu',
    lat: 27.6915,
    lng: 85.3420,
    studentsCount: '12,000+ Students'
  },
  {
    nameEn: 'Prithvi Narayan Campus (PNC)',
    nameNp: 'पृथ्वीनारायण क्याम्पस',
    city: 'Bagar, Pokhara',
    district: 'Kaski',
    lat: 28.2435,
    lng: 83.9856,
    studentsCount: '15,000+ Students'
  },
  {
    nameEn: 'Chitwan Medical College (CMC)',
    nameNp: 'चितवन मेडिकल कलेज',
    city: 'Bharatpur, Chitwan',
    district: 'Chitwan',
    lat: 27.6833,
    lng: 84.4333,
    studentsCount: '3,000+ Medical Students'
  }
];
