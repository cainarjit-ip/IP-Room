import { RoomListing } from '../types';

import heroImg from '../assets/images/hero_nepal_rental_1790335496477.jpg';
import studioKtmImg from '../assets/images/room_studio_kathmandu_1790335515183.jpg';
import bhkPokharaImg from '../assets/images/room_bhk_pokhara_1790335529427.jpg';
import singleLalitpurImg from '../assets/images/room_single_lalitpur_1790335543597.jpg';

export const INITIAL_ROOMS: RoomListing[] = [
  {
    id: 'room-ktm-01',
    title: 'Sunny Studio Flat with Study Desk & Fast WiFi near TU Gate',
    titleNp: 'टीयू गेट नजिकै घमाइलो स्टुडियो फ्ल्याट, अध्ययन डेस्क र तीव्र वाइफाइ सहित',
    description: 'Perfect for Tribhuvan University master/bachelor students. 4 minutes walk to TU Central Library and Science faculty. Peaceful residential neighborhood with 24/7 deep boring water supply, inverter backup during load-shedding, and dedicated study desk.',
    descriptionNp: 'त्रिभुवन विश्वविद्यालयका विद्यार्थीहरूका लागि उत्तम। केन्द्रीय पुस्तकालयबाट केवल ४ मिनेटको पैदल दूरी। २४ सै घण्टा बोरिङको पानी, इन्भर्टर ब्याकअप र छुट्टै पढ्ने टेबलको व्यवस्था।',
    price: 8500,
    deposit: 8500,
    roomType: 'studio',
    occupancyPreference: 'students_only',
    images: [
      studioKtmImg,
      heroImg,
      singleLalitpurImg
    ],
    virtualTour: [
      {
        id: 'scene-1',
        title: 'Main Bedroom & Study Space',
        titleNp: 'मुख्य सुत्ने कोठा र अध्ययन टेबल',
        panoramaUrl: studioKtmImg,
        hotspots: [
          {
            id: 'hs-1',
            pitch: 0,
            yaw: 65,
            targetSceneId: 'scene-2',
            title: 'Step onto Balcony',
            titleNp: 'बाल्कोनीमा जानुहोस्'
          },
          {
            id: 'hs-2',
            pitch: -5,
            yaw: -80,
            targetSceneId: 'scene-3',
            title: 'Enter Private Kitchen',
            titleNp: 'भान्सा कोठा हेर्नुहोस्'
          }
        ]
      },
      {
        id: 'scene-2',
        title: 'Sunny Balcony & Mountain View',
        titleNp: 'घमाइलो बाल्कोनी र हिमाल दृश्य',
        panoramaUrl: heroImg,
        hotspots: [
          {
            id: 'hs-3',
            pitch: 0,
            yaw: 175,
            targetSceneId: 'scene-1',
            title: 'Return to Bedroom',
            titleNp: 'सुत्ने कोठामा फर्किनुहोस्'
          }
        ]
      },
      {
        id: 'scene-3',
        title: 'Separate Kitchenette Area',
        titleNp: 'छुट्टै भान्सा क्षेत्र',
        panoramaUrl: singleLalitpurImg,
        hotspots: [
          {
            id: 'hs-4',
            pitch: 0,
            yaw: 110,
            targetSceneId: 'scene-1',
            title: 'Back to Bedroom',
            titleNp: 'कोठामा फर्किनुहोस्'
          }
        ]
      }
    ],
    location: {
      province: 'Bagmati Province',
      provinceId: 3,
      district: 'Kathmandu',
      municipality: 'Kirtipur Municipality',
      ward: 2,
      areaLandmark: 'Nayabazar, 300m from TU Main Gate',
      fullAddress: 'Nayabazar Ward 2, Kirtipur, Kathmandu, Bagmati Province',
      lat: 27.6812,
      lng: 85.2875,
      nearbyCampus: 'Tribhuvan University (Central Campus)',
      distanceToCampusMeters: 300
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: true,
      kitchenFacility: true,
      bikeParking: true,
      carParking: false,
      balcony: true,
      furnished: true,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Quiet study hours after 10:00 PM',
      'No loud parties or non-student overnight gatherings',
      'Lock main gate after 9:30 PM for safety',
      'Keep common balcony and staircase clean'
    ],
    houseRulesNp: [
      'राती १० बजेपछि पढाइको लागि शान्त वातावरण राख्नुपर्ने',
      'राती ९:३० बजेपछि मुख्य गेट बन्द गरिनेछ',
      'साझा बाल्कोनी र सिँढी सफा राख्नुपर्ने'
    ],
    waterSchedule: '24/7 Deep Boring + Overhead 4000L tank + Water filter dispenser',
    electricityRatePerUnit: 14,
    owner: {
      id: 'owner-01',
      name: 'Ram Bahadur Shrestha',
      phone: '+977 9841234567',
      whatsapp: '9779841234567',
      verified: true,
      superHost: true,
      citizenshipVerified: true,
      responseRate: '98%',
      responseTime: 'Within 15 mins',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.9,
      count: 18
    },
    reviews: [
      {
        id: 'rev-1',
        authorName: 'Suman Gautam',
        authorUniversity: 'TU Central Dept of Physics',
        rating: 5,
        cleanliness: 5,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Best room I rented during my 2 years of MSc! Water never ran out even in dry April. Landlord uncle is very respectful and supportive.',
        date: '2026-08-14'
      },
      {
        id: 'rev-2',
        authorName: 'Pratima Thapa',
        authorUniversity: 'TU Economics Dept',
        rating: 4.8,
        cleanliness: 5,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Very quiet for exam preparation and the high-speed WorldLink wifi worked smoothly throughout.',
        date: '2026-07-20'
      }
    ],
    availableFrom: 'Immediately',
    floor: '2nd Floor (South Facing)',
    featured: true,
    status: 'active',
    createdAt: '2026-09-01'
  },
  {
    id: 'room-lal-02',
    title: 'Cozy Single Bedroom for Engineering Student near Pulchowk Campus',
    titleNp: 'पुल्चोक इन्जिनियरिङ कलेज नजिकै सफा एकल कोठा (विद्यार्थीका लागि)',
    description: 'Only 450 meters from Pulchowk Engineering Campus gate. Ideal for IOE entrance exam preparation or ongoing engineering students. Features separate wooden wardrobe, study lamp, warm wooden flooring, and solar heated shower.',
    descriptionNp: 'पुल्चोक क्याम्पस गेटबाट मात्र ४५० मिटर। इन्जिनियरिङ विद्यार्थीका लागि अत्यन्त शान्त र उपयुक्त वातावरण। सोलार तातो पानी र पार्किङको राम्रो व्यवस्था।',
    price: 7000,
    deposit: 7000,
    roomType: 'single',
    occupancyPreference: 'students_only',
    images: [
      singleLalitpurImg,
      studioKtmImg,
      heroImg
    ],
    virtualTour: [
      {
        id: 'scene-lal-1',
        title: 'Study Bedroom',
        titleNp: 'अध्ययन शयनकक्ष',
        panoramaUrl: singleLalitpurImg,
        hotspots: [
          {
            id: 'hs-lal-1',
            pitch: 0,
            yaw: 80,
            targetSceneId: 'scene-lal-2',
            title: 'Shared Study Hall',
            titleNp: 'साझा अध्ययन हल'
          }
        ]
      },
      {
        id: 'scene-lal-2',
        title: 'Shared Study Hall & Balcony',
        titleNp: 'साझा हल र बाल्कोनी',
        panoramaUrl: heroImg,
        hotspots: [
          {
            id: 'hs-lal-2',
            pitch: 0,
            yaw: -100,
            targetSceneId: 'scene-lal-1',
            title: 'Back to Bedroom',
            titleNp: 'कोठामा फर्किनुहोस्'
          }
        ]
      }
    ],
    location: {
      province: 'Bagmati Province',
      provinceId: 3,
      district: 'Lalitpur',
      municipality: 'Lalitpur Metropolitan City',
      ward: 3,
      areaLandmark: 'Pulchowk, opposite LAB School alley',
      fullAddress: 'Pulchowk Ward 3, Lalitpur, Bagmati Province',
      lat: 27.6785,
      lng: 85.3168,
      nearbyCampus: 'Pulchowk Campus (IOE)',
      distanceToCampusMeters: 450
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: false,
      kitchenFacility: true,
      bikeParking: true,
      carParking: false,
      balcony: false,
      furnished: true,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Preferred male engineering student or IT trainee',
      'No smoking inside premises',
      'Shared kitchen area to be cleaned after cooking'
    ],
    houseRulesNp: [
      'इन्जिनियरिङ वा आईटी विद्यार्थीलाई प्राथमिकता',
      'धूम्रपान पूर्ण निषेध',
      'किचन प्रयोग गरेपछि सफा गर्नुपर्ने'
    ],
    waterSchedule: 'Melamchi supply 3 days/week + 24/7 Deep Boring backup',
    electricityRatePerUnit: 13,
    owner: {
      id: 'owner-02',
      name: 'Maya Devi Shakya',
      phone: '+977 9851098765',
      whatsapp: '9779851098765',
      verified: true,
      superHost: false,
      citizenshipVerified: true,
      responseRate: '95%',
      responseTime: 'Within 30 mins',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.8,
      count: 12
    },
    reviews: [
      {
        id: 'rev-3',
        authorName: 'Bibek Maharjan',
        authorUniversity: 'Pulchowk IOE Computer Dept',
        rating: 5,
        cleanliness: 5,
        waterSupply: 4,
        landlordBehavior: 5,
        comment: 'Super convenient for Pulchowk campus students. Can walk back even during late night project work.',
        date: '2026-08-02'
      }
    ],
    availableFrom: '2026-10-01',
    floor: '1st Floor',
    featured: true,
    status: 'active',
    createdAt: '2026-08-28'
  },
  {
    id: 'room-pok-03',
    title: 'Peaceful 1BHK Flat with Balcony near Bagar & Lakeside Pokhara',
    titleNp: 'बगर र लेकसाइड नजिकै बाल्कोनी सहितको शान्त १ बीएचके फ्ल्याट',
    description: 'Charming 1 BHK with panoramic view of Machhapuchhre on clear mornings. Located in Bagar, convenient for Prithvi Narayan Campus and WRC Lamachaur students. Includes separate private kitchen and attached bathroom.',
    descriptionNp: 'पोखराको शान्त वातावरणमा माछापुच्छ्रे हिमाल देखिने बाल्कोनी भएको १ बीएचके फ्ल्याट। पीएन क्याम्पस र इन्जिनियरिङ क्याम्पस नजिक। छुट्टै किचन र बाथरुम।',
    price: 13000,
    deposit: 15000,
    roomType: '1bhk',
    occupancyPreference: 'any',
    images: [
      bhkPokharaImg,
      heroImg,
      studioKtmImg
    ],
    location: {
      province: 'Gandaki Province',
      provinceId: 4,
      district: 'Kaski',
      municipality: 'Pokhara Metropolitan City',
      ward: 1,
      areaLandmark: 'Bagar, near Narayanthan Temple',
      fullAddress: 'Bagar Ward 1, Pokhara, Kaski, Gandaki Province',
      lat: 28.2410,
      lng: 83.9870,
      nearbyCampus: 'Prithvi Narayan Campus (PNC)',
      distanceToCampusMeters: 600
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: true,
      kitchenFacility: true,
      bikeParking: true,
      carParking: true,
      balcony: true,
      furnished: true,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Families or mature students welcome',
      'Pets allowed with prior consent',
      'Electricity sub-meter billed monthly on the 1st'
    ],
    houseRulesNp: [
      'परिवार वा विद्यार्थी दुवैलाई उपयुक्त',
      'सब-मिटर अनुसार मासिक विद्युत हिसाब'
    ],
    waterSchedule: '24/7 Pure Himalayan Mountain spring water pipeline',
    electricityRatePerUnit: 12,
    owner: {
      id: 'owner-03',
      name: 'Khem Raj Gurung',
      phone: '+977 9813456789',
      whatsapp: '9779813456789',
      verified: true,
      superHost: true,
      citizenshipVerified: true,
      responseRate: '100%',
      responseTime: 'Under 10 mins',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.9,
      count: 24
    },
    reviews: [
      {
        id: 'rev-4',
        authorName: 'Aarati Poudel',
        authorUniversity: 'PNC Pokhara',
        rating: 5,
        cleanliness: 5,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Mountain view from balcony is breathtaking. Pokhara tap water is abundant. Landlord Gurung dai is very helpful.',
        date: '2026-08-19'
      }
    ],
    availableFrom: 'Immediately',
    floor: 'Top Floor (3rd Floor)',
    featured: true,
    status: 'active',
    createdAt: '2026-09-05'
  },
  {
    id: 'room-ban-04',
    title: 'Modern Girls-Only Shared Room with Attached Washroom in New Baneshwor',
    titleNp: 'नयाँ बानेश्वरमा छात्राहरूका लागि आधुनिक साझा कोठा (संलग्न बाथरुम सहित)',
    description: 'Safe and secure living space for female students or young working women. Walking distance to Apex College, Ace Institute, and Minbhawan Campus. Fully equipped with CCTV on main gate, biometric entry, and purified drinking water.',
    descriptionNp: 'छात्रा तथा कामकाजी महिलाहरूका लागि सुरक्षित कोठा। एपेक्स कलेज र मिनभवन क्याम्पस नजिक। मुख्य गेटमा सीसीटीभी र पिउने पानीको फिल्टर उपलब्ध।',
    price: 6500,
    deposit: 6500,
    roomType: 'shared',
    occupancyPreference: 'girls_only',
    images: [
      heroImg,
      singleLalitpurImg,
      studioKtmImg
    ],
    location: {
      province: 'Bagmati Province',
      provinceId: 3,
      district: 'Kathmandu',
      municipality: 'Kathmandu Metropolitan City',
      ward: 10,
      areaLandmark: 'New Baneshwor, behind Everest Hotel',
      fullAddress: 'New Baneshwor Ward 10, Kathmandu, Bagmati Province',
      lat: 27.6920,
      lng: 85.3415,
      nearbyCampus: 'Apex College / Baneshwor Colleges',
      distanceToCampusMeters: 350
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: true,
      kitchenFacility: true,
      bikeParking: true,
      carParking: false,
      balcony: true,
      furnished: true,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Strictly girls only',
      'Gate closed at 9:00 PM',
      'No unauthorized male visitors inside the room'
    ],
    houseRulesNp: [
      'छात्राहरूका लागि मात्र सुरक्षित',
      'राती ९:०० बजे गेट बन्द हुने',
      'अपरिचित व्यक्ति प्रवेश निषेध'
    ],
    waterSchedule: 'Melamchi supply + Underground 8000L tank backup (24/7 in taps)',
    electricityRatePerUnit: 14,
    owner: {
      id: 'owner-04',
      name: 'Sabitri Koirala',
      phone: '+977 9841887766',
      whatsapp: '9779841887766',
      verified: true,
      superHost: true,
      citizenshipVerified: true,
      responseRate: '99%',
      responseTime: 'Instant',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.9,
      count: 31
    },
    reviews: [
      {
        id: 'rev-5',
        authorName: 'Sneha Kafle',
        authorUniversity: 'Ace Institute of Management',
        rating: 5,
        cleanliness: 5,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Extremely safe for girls living away from home. Auntie treats us like family and makes sure we are comfortable.',
        date: '2026-08-30'
      }
    ],
    availableFrom: 'Immediately',
    floor: '2nd Floor',
    featured: true,
    status: 'active',
    createdAt: '2026-09-10'
  },
  {
    id: 'room-put-05',
    title: 'Spacious 2BHK Apartment with Kitchen & Balcony in Putalisadak',
    titleNp: 'पुतलीसडकमा भान्सा र बाल्कोनी भएको फराकिलो २ बीएचके अपार्टमेन्ट',
    description: 'Located in the educational heart of Kathmandu. 3 minutes walk to Shankar Dev Campus, Star Mall, and major tuition centers. Ideal for group of 3-4 college friends sharing expenses.',
    descriptionNp: 'काठमाडौँको शैक्षिक केन्द्र पुतलीसडकमा। शंकरदेव क्याम्पस नजिक। ३-४ जना साथीहरू मिलेर बस्नका लागि अत्यन्त उपयुक्त।',
    price: 18000,
    deposit: 20000,
    roomType: '2bhk',
    occupancyPreference: 'students_only',
    images: [
      studioKtmImg,
      bhkPokharaImg,
      heroImg
    ],
    location: {
      province: 'Bagmati Province',
      provinceId: 3,
      district: 'Kathmandu',
      municipality: 'Kathmandu Metropolitan City',
      ward: 28,
      areaLandmark: 'Putalisadak, near Shankar Dev Gate',
      fullAddress: 'Putalisadak Ward 28, Kathmandu, Bagmati Province',
      lat: 27.7050,
      lng: 85.3225,
      nearbyCampus: 'Shankar Dev Campus',
      distanceToCampusMeters: 250
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: true,
      kitchenFacility: true,
      bikeParking: true,
      carParking: false,
      balcony: true,
      furnished: false,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Clean common corridor',
      'Timely rent payment by 5th of Nepali month'
    ],
    houseRulesNp: [
      'महिनाको ५ गतेभित्र भाडा भुक्तानी गर्नुपर्ने',
      'शान्त वातावरण कायम राख्नुपर्ने'
    ],
    waterSchedule: 'Melamchi water direct connection + Boring backup daily',
    electricityRatePerUnit: 14,
    owner: {
      id: 'owner-05',
      name: 'Deepak Raj Pandey',
      phone: '+977 9851122334',
      whatsapp: '9779851122334',
      verified: true,
      superHost: false,
      citizenshipVerified: true,
      responseRate: '92%',
      responseTime: 'Within 45 mins',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.7,
      count: 9
    },
    reviews: [
      {
        id: 'rev-6',
        authorName: 'Rohan Shrestha',
        authorUniversity: 'Shankar Dev Campus BBA',
        rating: 5,
        cleanliness: 4,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Three of us classmates shared this flat. Saved huge money on bus fare because campus is right across the street.',
        date: '2026-07-11'
      }
    ],
    availableFrom: '2026-10-15',
    floor: '3rd Floor',
    featured: false,
    status: 'active',
    createdAt: '2026-09-02'
  },
  {
    id: 'room-cht-06',
    title: 'Comfortable Single Room near Chitwan Medical College (CMC)',
    titleNp: 'चितवन मेडिकल कलेज (सीएमसी) नजिकै आरामदायी एकल कोठा',
    description: 'Specially suited for MBBS/BDS/Nursing students and doctors doing residency at CMC Bharatpur. Includes inverter backup for hot summer days, bike parking, and solar water.',
    descriptionNp: 'भरतपुर चितवनमा मेडिकल र नर्सिङ विद्यार्थीहरूका लागि विशेष कोठा। गर्मी महिनामा इन्भर्टर ब्याकअप र शान्त अध्ययन कोठा।',
    price: 6000,
    deposit: 6000,
    roomType: 'single',
    occupancyPreference: 'students_only',
    images: [
      singleLalitpurImg,
      bhkPokharaImg,
      studioKtmImg
    ],
    location: {
      province: 'Bagmati Province',
      provinceId: 3,
      district: 'Chitwan',
      municipality: 'Bharatpur Metropolitan City',
      ward: 10,
      areaLandmark: 'Chaubiskothi, 400m from CMC Hospital',
      fullAddress: 'Chaubiskothi Ward 10, Bharatpur, Chitwan, Bagmati Province',
      lat: 27.6840,
      lng: 84.4320,
      nearbyCampus: 'Chitwan Medical College (CMC)',
      distanceToCampusMeters: 400
    },
    amenities: {
      wifi: true,
      water24x7: true,
      hotWaterSolar: true,
      attachedBathroom: true,
      kitchenFacility: false,
      bikeParking: true,
      carParking: false,
      balcony: true,
      furnished: true,
      electricityBackup: true,
      cctvSecurity: true
    },
    houseRules: [
      'Doctors/Medical students preferred due to irregular hospital duty shifts',
      'Respect day-sleepers after night duties'
    ],
    houseRulesNp: [
      'अस्पतालको नाइट ड्युटी हुने भएकाले शान्ति कायम राख्नुपर्ने'
    ],
    waterSchedule: '24/7 Deep Boring running water',
    electricityRatePerUnit: 12,
    owner: {
      id: 'owner-06',
      name: 'Harish Chandra Adhikari',
      phone: '+977 9855012345',
      whatsapp: '9779855012345',
      verified: true,
      superHost: true,
      citizenshipVerified: true,
      responseRate: '97%',
      responseTime: 'Within 20 mins',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80'
    },
    ratings: {
      average: 4.8,
      count: 15
    },
    reviews: [
      {
        id: 'rev-7',
        authorName: 'Dr. Sandhya Acharya',
        authorUniversity: 'CMC Bharatpur Intern',
        rating: 5,
        cleanliness: 5,
        waterSupply: 5,
        landlordBehavior: 5,
        comment: 'Very accommodating for medical interns with odd hospital hours. Water and inverter never failed.',
        date: '2026-08-10'
      }
    ],
    availableFrom: 'Immediately',
    floor: 'Ground Floor',
    featured: false,
    status: 'active',
    createdAt: '2026-09-08'
  }
];

export const INITIAL_DISPUTES = [
  {
    id: 'disp-01',
    bookingId: 'BK-9921',
    roomTitle: 'Sunny Studio Flat with Study Desk & Fast WiFi near TU Gate',
    complainantName: 'Aayush Sharma (Student)',
    complainantRole: 'renter' as const,
    issueType: 'deposit_refund' as const,
    subject: 'Deposit return delay after semester completion',
    description: 'I moved out on Bhadra 30 with 35 days notice and left room spotless. Seeking mediation for remaining NPR 8,500 deposit return via Khalti.',
    status: 'open' as const,
    resolutionNotes: 'Admin requested owner bank details for auto-settlement.',
    createdAt: '2026-09-20'
  },
  {
    id: 'disp-02',
    bookingId: 'BK-8812',
    roomTitle: 'Cozy Single Bedroom for Engineering Student near Pulchowk',
    complainantName: 'Ram Bahadur Shrestha (Landlord)',
    complainantRole: 'owner' as const,
    issueType: 'water_shortage' as const,
    subject: 'Temporary road construction damaged municipal pipeline',
    description: 'Road widening disrupted Melamchi pipe. Landlord arranged private water tanker, tenant agreed on shared tanker cost adjustment.',
    status: 'resolved' as const,
    resolutionNotes: 'Resolved mutually: Landlord subsidized 70% of tanker water cost.',
    createdAt: '2026-09-12'
  }
];
