import React, { useState } from 'react';
import { RoomListing, DisputeTicket, Language } from '../types';
import { getTranslation } from '../data/translations';
import {
  ShieldAlert,
  CheckCircle,
  XCircle,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  MapPin,
  FileCheck,
  Check
} from 'lucide-react';

interface AdminDashboardProps {
  rooms: RoomListing[];
  disputes: DisputeTicket[];
  language: Language;
  onApproveRoom: (roomId: string) => void;
  onRejectRoom: (roomId: string) => void;
  onResolveDispute: (disputeId: string, notes: string) => void;
  onSelectRoom: (room: RoomListing) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  rooms,
  disputes,
  language,
  onApproveRoom,
  onRejectRoom,
  onResolveDispute,
  onSelectRoom,
}) => {
  const t = getTranslation(language);
  const [resolutionText, setResolutionText] = useState('');
  const [activeDisputeId, setActiveDisputeId] = useState<string | null>(null);

  // Platform metrics
  const totalListings = rooms.length + 185;
  const totalVerifiedOwners = 142;
  const platformGMV = 'रु. 1,48,50,000';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="bg-purple-950 text-white rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 shadow-xl border border-purple-900">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="font-bold text-xs bg-purple-900 text-purple-200 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              System Admin Console · नेपाल
            </span>
          </div>
          <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
            Platform Moderation & Trust Center
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-purple-200">
            Oversee room listing approvals, inspect landlord citizenship credentials, and resolve escrow tenancy disputes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-purple-900/60 p-3 rounded-xl border border-purple-800 text-center">
            <span className="text-[10px] text-purple-300 block uppercase">Escrow Protected GMV</span>
            <span className="font-mono font-bold text-base text-emerald-400">{platformGMV}</span>
          </div>
        </div>
      </div>

      {/* Platform Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Active Verified Rooms</span>
            <BarChart3 className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {totalListings} Listings
          </div>
          <span className="text-[11px] text-slate-500">Across Kathmandu, Lalitpur, Pokhara, Chitwan</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Citizenship Verified Landlords</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {totalVerifiedOwners} Owners
          </div>
          <span className="text-[11px] text-emerald-700 font-medium">99.4% Dispute-free rate</span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Active Dispute Tickets</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
            {disputes.filter(d => d.status !== 'resolved').length} Pending
          </div>
          <span className="text-[11px] text-amber-700 font-medium">Avg settlement: 24 hours</span>
        </div>
      </div>

      {/* Dispute Resolution Center */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-purple-700" />
            <h2 className="font-bold text-sm text-slate-900">{t.activeDisputes}</h2>
          </div>
          <span className="text-xs text-slate-500">Neutral Escrow Mediation</span>
        </div>

        <div className="space-y-4">
          {disputes.map(ticket => (
            <div
              key={ticket.id}
              className={`p-4 rounded-xl border text-xs space-y-2 transition ${
                ticket.status === 'resolved'
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : 'bg-amber-50/40 border-amber-200'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-slate-800">{ticket.id}</span>
                  <span className="text-slate-400">·</span>
                  <span className="font-semibold text-slate-900">{ticket.subject}</span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider ${
                    ticket.status === 'resolved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {ticket.status}
                </span>
              </div>

              <div className="text-slate-600">
                <strong>Complainant:</strong> {ticket.complainantName} ({ticket.complainantRole}) · <strong>Property:</strong> {ticket.roomTitle}
              </div>

              <p className="text-slate-700 bg-white/80 p-2.5 rounded-lg border border-slate-200/60 leading-relaxed">
                "{ticket.description}"
              </p>

              {ticket.resolutionNotes && (
                <div className="text-[11px] text-emerald-800 font-medium">
                  <strong>Resolution:</strong> {ticket.resolutionNotes}
                </div>
              )}

              {ticket.status !== 'resolved' && (
                <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                  <input
                    type="text"
                    placeholder="Enter resolution verdict (e.g., Refund approved via Khalti or Landlord agreement)..."
                    value={activeDisputeId === ticket.id ? resolutionText : ''}
                    onChange={e => {
                      setActiveDisputeId(ticket.id);
                      setResolutionText(e.target.value);
                    }}
                    className="flex-1 bg-white border border-slate-200 rounded-lg p-2 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      onResolveDispute(ticket.id, resolutionText || 'Resolved mutually with deposit settlement.');
                      setResolutionText('');
                      setActiveDisputeId(null);
                    }}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold text-xs whitespace-nowrap"
                  >
                    Resolve & Settle
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Moderation Queue of Listings */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-700" />
            <h2 className="font-bold text-sm text-slate-900">{t.pendingApprovals}</h2>
          </div>
          <span className="text-xs text-slate-500">Checking quality, location & photo compliance</span>
        </div>

        <div className="divide-y divide-slate-100">
          {rooms.slice(0, 4).map(room => (
            <div key={room.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <img
                  src={room.images[0]}
                  alt={room.title}
                  className="w-12 h-12 rounded-lg object-cover shrink-0"
                />
                <div>
                  <div className="font-bold text-slate-900 line-clamp-1">{room.title}</div>
                  <div className="text-slate-500 mt-0.5">
                    {room.location.municipality} · Landlord: <strong>{room.owner.name}</strong> ({room.owner.citizenshipVerified ? 'Citizenship Verified' : 'Unverified'})
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSelectRoom(room)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium"
                >
                  Inspect
                </button>
                <button
                  type="button"
                  onClick={() => onApproveRoom(room.id)}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Approved</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
