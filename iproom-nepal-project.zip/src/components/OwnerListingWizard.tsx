import React, { useState } from 'react';
import { RoomListing, RoomType, OccupancyPreference, Language } from '../types';
import { getTranslation } from '../data/translations';
import { NEPAL_PROVINCES, NEPAL_CAMPUSES } from '../data/nepalGeo';
import { X, Check, ArrowRight, ArrowLeft, Upload, ShieldCheck, Droplets, Zap, Image as ImageIcon } from 'lucide-react';
import heroImg from '../assets/images/hero_nepal_rental_1790335496477.jpg';
import studioKtmImg from '../assets/images/room_studio_kathmandu_1790335515183.jpg';

interface OwnerListingWizardProps {
  language: Language;
  onClose: () => void;
  onSubmitNewRoom: (room: RoomListing) => void;
}

export const OwnerListingWizard: React.FC<OwnerListingWizardProps> = ({
  language,
  onClose,
  onSubmitNewRoom,
}) => {
  const t = getTranslation(language);
  const [currentStep, setCurrentStep] = useState(1);

  // Form states
  const [title, setTitle] = useState('');
  const [titleNp, setTitleNp] = useState('');
  const [description, setDescription] = useState('');
  const [roomType, setRoomType] = useState<RoomType>('single');
  const [occupancyPreference, setOccupancyPreference] = useState<OccupancyPreference>('students_only');
  const [floor, setFloor] = useState('2nd Floor');

  // Location
  const [province, setProvince] = useState('Bagmati Province');
  const [district, setDistrict] = useState('Kathmandu');
  const [municipality, setMunicipality] = useState('Kathmandu Metropolitan City');
  const [ward, setWard] = useState(10);
  const [areaLandmark, setAreaLandmark] = useState('');
  const [nearbyCampus, setNearbyCampus] = useState('Tribhuvan University (Central Campus)');
  const [distanceToCampus, setDistanceToCampus] = useState(350);

  // Financials
  const [price, setPrice] = useState(8000);
  const [deposit, setDeposit] = useState(8000);
  const [electricityRate, setElectricityRate] = useState(14);
  const [waterSchedule, setWaterSchedule] = useState('24/7 Deep Boring + Melamchi weekly');

  // Amenities
  const [amenities, setAmenities] = useState({
    wifi: true,
    water24x7: true,
    hotWaterSolar: true,
    attachedBathroom: true,
    kitchenFacility: true,
    bikeParking: true,
    carParking: false,
    balcony: true,
    furnished: true,
    electricityBackup: true,
    cctvSecurity: true,
  });

  // House Rules
  const [houseRules, setHouseRules] = useState('Quiet study hours after 10:00 PM\nLock gate after 9:30 PM\nClean common area after cooking');

  // Citizenship / ID
  const [citizenshipUploaded, setCitizenshipUploaded] = useState(true);

  const availableDistricts = NEPAL_PROVINCES.find(p => p.nameEn === province)?.districts || [];
  const currentDistrictObj = availableDistricts.find(d => d.nameEn === district);
  const availableMunicipalities = currentDistrictObj ? currentDistrictObj.municipalities : [];

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const createdRoom: RoomListing = {
      id: `room-custom-${Date.now()}`,
      title: title || 'Newly Listed Clean Student Room in Nepal',
      titleNp: titleNp || 'नेपालमा भर्खरै सूचीकृत गरिएको सफा विद्यार्थी कोठा',
      description: description || 'Well-ventilated student room with reliable water and high-speed internet.',
      descriptionNp: 'विद्यार्थीहरूका लागि उपयुक्त, पानीको राम्रो प्रबन्ध भएको शान्त कोठा।',
      price: Number(price),
      deposit: Number(deposit),
      roomType,
      occupancyPreference,
      images: [
        studioKtmImg,
        heroImg
      ],
      location: {
        province,
        provinceId: 3,
        district,
        municipality,
        ward: Number(ward),
        areaLandmark: areaLandmark || 'Near Chowk',
        fullAddress: `${areaLandmark || 'Main Road'} Ward ${ward}, ${municipality}, ${district}, ${province}`,
        lat: 27.695,
        lng: 85.325,
        nearbyCampus,
        distanceToCampusMeters: Number(distanceToCampus)
      },
      amenities,
      houseRules: houseRules.split('\n').filter(Boolean),
      houseRulesNp: [
        'राती १० बजेपछि शान्त रहनुपर्ने',
        'गेट समयमै बन्द गर्नुपर्ने'
      ],
      waterSchedule,
      electricityRatePerUnit: Number(electricityRate),
      owner: {
        id: 'owner-current',
        name: 'Ram Bahadur Shrestha',
        phone: '+977 9841234567',
        whatsapp: '9779841234567',
        verified: true,
        superHost: true,
        citizenshipVerified: true,
        responseRate: '100%',
        responseTime: 'Instant',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
      },
      ratings: {
        average: 5.0,
        count: 1
      },
      reviews: [
        {
          id: 'rev-init',
          authorName: 'IP Room Verification Inspector',
          authorUniversity: 'Admin Audit Team',
          rating: 5,
          cleanliness: 5,
          waterSupply: 5,
          landlordBehavior: 5,
          comment: 'Premises audited in person. Melamchi pipeline and deep boring operational.',
          date: '2026-09-25'
        }
      ],
      availableFrom: 'Immediately',
      floor,
      featured: true,
      status: 'active',
      createdAt: new Date().toISOString().split('T')[0]
    };

    onSubmitNewRoom(createdRoom);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div>
            <h2 className="font-bold text-base">
              {language === 'np' ? 'नयाँ कोठा सूचीकरण विजार्ड' : 'List Your Room on IP Room'}
            </h2>
            <p className="text-xs text-slate-300">
              Reach thousands of students across Nepal with verified badge
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          {[
            { step: 1, label: t.wizardStep1 },
            { step: 2, label: t.wizardStep2 },
            { step: 3, label: t.wizardStep3 },
            { step: 4, label: t.wizardStep4 },
            { step: 5, label: t.wizardStep5 },
          ].map(s => (
            <div
              key={s.step}
              className={`flex items-center gap-1.5 ${
                currentStep === s.step
                  ? 'text-emerald-700 font-bold'
                  : currentStep > s.step
                  ? 'text-slate-700'
                  : 'text-slate-400'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${
                  currentStep === s.step
                    ? 'bg-emerald-700 text-white'
                    : currentStep > s.step
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-200 text-slate-600'
                }`}
              >
                {currentStep > s.step ? <Check className="w-3 h-3" /> : s.step}
              </span>
              <span className="hidden sm:inline">{s.label}</span>
            </div>
          ))}
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* Step 1: Basic Info */}
          {currentStep === 1 && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Listing Title (English) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Bright Sunny Room with Study Table near TU Gate"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Listing Title (नेपाली)
                </label>
                <input
                  type="text"
                  placeholder="जस्तै: कीर्तिपुर टीयू गेट नजिकै घमाइलो कोठा"
                  value={titleNp}
                  onChange={e => setTitleNp(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Room Type
                  </label>
                  <select
                    value={roomType}
                    onChange={e => setRoomType(e.target.value as RoomType)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="single">Single Room (एकल कोठा)</option>
                    <option value="shared">Shared Room (साझा कोठा)</option>
                    <option value="1bhk">1 BHK</option>
                    <option value="2bhk">2 BHK</option>
                    <option value="studio">Studio Flat</option>
                    <option value="full_flat">Full Flat / House</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Preferred Occupancy
                  </label>
                  <select
                    value={occupancyPreference}
                    onChange={e => setOccupancyPreference(e.target.value as OccupancyPreference)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="students_only">Students Only (विद्यार्थी मात्र)</option>
                    <option value="girls_only">Girls Only (छात्राहरू मात्र)</option>
                    <option value="boys_only">Boys Only (छात्रहरू मात्र)</option>
                    <option value="family">Family / Professional</option>
                    <option value="any">Any Suitable Tenant</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Floor Level
                </label>
                <input
                  type="text"
                  placeholder="e.g., 2nd Floor (South Facing)"
                  value={floor}
                  onChange={e => setFloor(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  placeholder="Describe natural lighting, neighborhood, distance to markets..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>
          )}

          {/* Step 2: Location in Nepal */}
          {currentStep === 2 && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Province (प्रदेश)
                  </label>
                  <select
                    value={province}
                    onChange={e => setProvince(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {NEPAL_PROVINCES.map(p => (
                      <option key={p.id} value={p.nameEn}>{p.nameEn} ({p.nameNp})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    District (जिल्ला)
                  </label>
                  <select
                    value={district}
                    onChange={e => setDistrict(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {availableDistricts.map(d => (
                      <option key={d.nameEn} value={d.nameEn}>{d.nameEn} ({d.nameNp})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Municipality / Metro (पालिका)
                  </label>
                  <select
                    value={municipality}
                    onChange={e => setMunicipality(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {availableMunicipalities.map(m => (
                      <option key={m.nameEn} value={m.nameEn}>{m.nameEn}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Ward Number (वडा नं.)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="35"
                    value={ward}
                    onChange={e => setWard(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Street / Landmark (सडक वा चोक)
                </label>
                <input
                  type="text"
                  placeholder="e.g., Nayabazar, opposite Shiva Temple"
                  value={areaLandmark}
                  onChange={e => setAreaLandmark(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Nearby Campus / College
                  </label>
                  <select
                    value={nearbyCampus}
                    onChange={e => setNearbyCampus(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    {NEPAL_CAMPUSES.map(c => (
                      <option key={c.nameEn} value={c.nameEn}>{c.nameEn}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Distance to Campus (Meters)
                  </label>
                  <input
                    type="number"
                    value={distanceToCampus}
                    onChange={e => setDistanceToCampus(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Pricing & Deposit */}
          {currentStep === 3 && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Monthly Rent (NPR) *
                  </label>
                  <input
                    type="number"
                    min="2000"
                    step="500"
                    value={price}
                    onChange={e => setPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Security Deposit (Refundable) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="500"
                    value={deposit}
                    onChange={e => setDeposit(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>Sub-meter Electricity Rate (NPR per unit)</span>
                </label>
                <input
                  type="number"
                  min="10"
                  max="20"
                  value={electricityRate}
                  onChange={e => setElectricityRate(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
                <span className="text-[11px] text-slate-500 block mt-1">
                  Standard Nepal rate is NPR 12-15 to cover shared motor pumping and stairway lights.
                </span>
              </div>
            </div>
          )}

          {/* Step 4: Amenities & Water Facility */}
          {currentStep === 4 && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1 flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5 text-sky-600" />
                  <span>Transparent Water Schedule Description *</span>
                </label>
                <input
                  type="text"
                  value={waterSchedule}
                  onChange={e => setWaterSchedule(e.target.value)}
                  placeholder="e.g., 24/7 Deep Boring + Melamchi twice weekly + 5,000L tank"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-2">
                  Check Available Amenities
                </label>
                <div className="grid grid-cols-2 gap-2 text-slate-700">
                  {Object.entries({
                    water24x7: '24/7 Water Supply',
                    hotWaterSolar: 'Solar Hot Water',
                    attachedBathroom: 'Attached Bathroom',
                    kitchenFacility: 'Kitchen Space Included',
                    bikeParking: 'Bike/Scooter Parking',
                    wifi: 'High-Speed WiFi',
                    electricityBackup: 'Inverter / Solar Backup',
                    balcony: 'Balcony',
                    furnished: 'Bed & Study Table Included',
                    cctvSecurity: 'CCTV Security Gate'
                  }).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg cursor-pointer">
                      <input
                        type="checkbox"
                        checked={amenities[key as keyof typeof amenities]}
                        onChange={e => setAmenities(prev => ({ ...prev, [key]: e.target.checked }))}
                        className="rounded accent-emerald-600"
                      />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  House Rules (one per line)
                </label>
                <textarea
                  rows={3}
                  value={houseRules}
                  onChange={e => setHouseRules(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>
          )}

          {/* Step 5: Photos, 360° Virtual Tour & ID Verification */}
          {currentStep === 5 && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-2">
                  Room Photos (Preview Generated Real Architectural Photos)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative rounded-lg overflow-hidden border border-slate-200 aspect-[4/3]">
                    <img src={studioKtmImg} alt="Preview 1" className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">
                      Main Photo
                    </span>
                  </div>
                  <div className="relative rounded-lg overflow-hidden border border-slate-200 aspect-[4/3]">
                    <img src={heroImg} alt="Preview 2" className="w-full h-full object-cover" />
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">
                      Balcony View
                    </span>
                  </div>
                </div>
              </div>

              {/* 360-Degree Panoramic Tour Upload Configuration */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-emerald-100 text-emerald-800 rounded-lg">
                      <ImageIcon className="w-4 h-4" />
                    </span>
                    <div>
                      <h4 className="font-bold text-slate-900">
                        360° Panoramic Virtual Tour Setup (Recommended)
                      </h4>
                      <p className="text-[11px] text-slate-600">
                        Enable prospective students to tour the flat room-by-room virtually.
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    Active
                  </span>
                </div>

                <div className="space-y-2 pt-1 border-t border-emerald-200/60">
                  <div className="flex items-center justify-between text-[11px] bg-white p-2 rounded border border-emerald-100">
                    <span className="font-semibold text-slate-800">Scene 1: Bedroom & Study Area</span>
                    <span className="text-emerald-700 font-mono">2 Hotspots linked (Balcony, Kitchen)</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] bg-white p-2 rounded border border-emerald-100">
                    <span className="font-semibold text-slate-800">Scene 2: Mountain View Balcony</span>
                    <span className="text-emerald-700 font-mono">1 Hotspot linked (Bedroom)</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500">
                  Tip: Use your smartphone's Panorama mode or 360 camera to capture high resolution scenes.
                </div>
              </div>

              {/* Citizenship Verification */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-100 text-blue-700 rounded-lg shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">
                      Nepali Citizenship Card Verification (नागरिकता प्रमाणीकरण)
                    </h3>
                    <p className="text-slate-600 text-xs mt-0.5">
                      Citizenship verified landlords receive 3.5x more student inquiries and the official "ID Verified" trust badge.
                    </p>
                    <div className="mt-2.5 flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-100/80 px-2 py-1 rounded">
                        <Check className="w-3.5 h-3.5" />
                        <span>Document ID: 27-01-72-XXXXX Verified</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          {currentStep > 1 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(prev => prev - 1)}
              className="inline-flex items-center gap-1 px-4 py-2 bg-white border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-100 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {currentStep < 5 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(prev => prev + 1)}
              className="inline-flex items-center gap-1 px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold transition shadow-xs"
            >
              <span>Continue</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinalSubmit}
              className="inline-flex items-center gap-1.5 px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-md active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>{t.submitListing}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
