import React, { useState } from 'react';
import { UserProfile, UserRole, Language } from '../types';
import { getTranslation } from '../data/translations';
import {
  X,
  Lock,
  Mail,
  User,
  Phone,
  School,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { loginWithGoogle, loginWithFacebook, registerWithEmail, loginWithEmail } from '../services/firebase';

interface AuthModalProps {
  language: Language;
  onClose: () => void;
  onSuccess: (profile: UserProfile) => void;
  initialMode?: 'login' | 'signup';
  initialRole?: UserRole;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  language,
  onClose,
  onSuccess,
  initialMode = 'login',
  initialRole = 'renter',
}) => {
  const t = getTranslation(language);
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [role, setRole] = useState<UserRole>(initialRole);

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('+977 98');
  const [university, setUniversity] = useState('Tribhuvan University (Central Campus)');
  const [citizenshipVerified, setCitizenshipVerified] = useState(true);

  const [loadingProvider, setLoadingProvider] = useState<'google' | 'facebook' | 'email' | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Handle Google Sign-in
  const handleGoogleAuth = async () => {
    setLoadingProvider('google');
    setErrorMsg('');
    try {
      const profile = await loginWithGoogle(role);
      onSuccess(profile);
      onClose();
    } catch (err: any) {
      console.warn('Google sign-in error:', err);
      setErrorMsg(err?.message || 'Google sign-in could not be completed. Please try again.');
    } finally {
      setLoadingProvider(null);
    }
  };

  // Handle Facebook Sign-in
  const handleFacebookAuth = async () => {
    setLoadingProvider('facebook');
    setErrorMsg('');
    try {
      const profile = await loginWithFacebook(role);
      onSuccess(profile);
      onClose();
    } catch (err: any) {
      console.warn('Facebook sign-in error:', err);
      setErrorMsg(err?.message || 'Facebook sign-in could not be completed. Please try again.');
    } finally {
      setLoadingProvider(null);
    }
  };

  // Handle Email Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingProvider('email');
    setErrorMsg('');

    try {
      if (mode === 'signup') {
        if (!name.trim()) {
          setErrorMsg('Please enter your full legal name.');
          setLoadingProvider(null);
          return;
        }
        const profile = await registerWithEmail(
          email,
          password,
          name,
          role,
          phone,
          role === 'renter' ? university : undefined
        );
        onSuccess(profile);
      } else {
        const profile = await loginWithEmail(email, password);
        onSuccess(profile);
      }
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoadingProvider(null);
    }
  };

  // Quick Demo Logins
  const handleQuickDemo = (demoRole: UserRole) => {
    const demoProfiles: Record<UserRole, UserProfile> = {
      renter: {
        id: 'usr-student-demo',
        name: 'Aayush Sharma (TU Student)',
        email: 'aayush.sharma@gmail.com',
        phone: '+977 9841998877',
        role: 'renter',
        avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
        verified: true,
        university: 'Tribhuvan University (Central Campus)',
        studentIdVerified: true,
      },
      owner: {
        id: 'usr-owner-demo',
        name: 'Ram Bahadur Shrestha (Landlord)',
        email: 'ram.shrestha@gmail.com',
        phone: '+977 9841234567',
        role: 'owner',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        verified: true,
        citizenshipVerified: true,
      },
      admin: {
        id: 'usr-admin-demo',
        name: 'Admin Moderator (Nepal)',
        email: 'admin@iproom.com.np',
        phone: '+977 1 4422XXX',
        role: 'admin',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
        verified: true,
        citizenshipVerified: true,
      },
    };

    onSuccess(demoProfiles[demoRole]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="relative bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-black text-xs">
                IP
              </div>
              <h2 className="font-bold text-base">
                {mode === 'login'
                  ? language === 'np' ? 'IP Room मा लगइन' : 'Sign in to IP Room'
                  : language === 'np' ? 'नयाँ खाता सिर्जना गर्नुहोस्' : 'Create an IP Room Account'}
              </h2>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Connecting 150,000+ students and verified room owners across Nepal
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Login vs Sign Up */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-3 text-center transition ${
              mode === 'login'
                ? 'bg-white text-emerald-800 border-b-2 border-emerald-600 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {language === 'np' ? 'लगइन (Sign In)' : 'Sign In'}
          </button>
          <button
            type="button"
            onClick={() => setMode('signup')}
            className={`flex-1 py-3 text-center transition ${
              mode === 'signup'
                ? 'bg-white text-emerald-800 border-b-2 border-emerald-600 font-bold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {language === 'np' ? 'दर्ता (Sign Up)' : 'Register Account'}
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Role Selector (Applies to both OAuth & Email) */}
          <div>
            <label className="font-semibold text-slate-700 block mb-1.5 text-xs flex items-center justify-between">
              <span>{language === 'np' ? 'खाता भूमिका (Role):' : 'Signing in as:'}</span>
              <span className="text-[11px] text-slate-400 font-normal">
                {role === 'renter' ? 'Student / Tenant' : role === 'owner' ? 'Room Landlord' : 'Admin'}
              </span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setRole('renter')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  role === 'renter'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-base">🎓</span>
                  <span className="font-semibold text-xs">Student / Renter</span>
                </div>
                <span className="block text-[10px] text-slate-400 font-normal mt-0.5">विद्यार्थी / भाडावाल</span>
              </button>

              <button
                type="button"
                onClick={() => setRole('owner')}
                className={`p-2.5 rounded-xl border text-left transition ${
                  role === 'owner'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold shadow-xs'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-base">🏠</span>
                  <span className="font-semibold text-xs">Room Owner</span>
                </div>
                <span className="block text-[10px] text-slate-400 font-normal mt-0.5">घरधनी / कोठा धनी</span>
              </button>
            </div>
          </div>

          {/* OAuth Providers: Google & Facebook */}
          <div className="space-y-2">
            <button
              type="button"
              onClick={handleGoogleAuth}
              disabled={loadingProvider !== null}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-semibold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 active:scale-95 disabled:opacity-60"
            >
              {loadingProvider === 'google' ? (
                <div className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
              ) : (
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              )}
              <span>
                {loadingProvider === 'google'
                  ? 'Connecting to Google Auth...'
                  : mode === 'signup'
                  ? 'Sign up with Google'
                  : 'Continue with Google'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleFacebookAuth}
              disabled={loadingProvider !== null}
              className="w-full py-2.5 px-4 bg-[#1877F2] hover:bg-[#166fe5] text-white font-semibold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 active:scale-95 disabled:opacity-60"
            >
              {loadingProvider === 'facebook' ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <svg className="w-4 h-4 shrink-0 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              )}
              <span>
                {loadingProvider === 'facebook'
                  ? 'Connecting to Facebook Auth...'
                  : mode === 'signup'
                  ? 'Sign up with Facebook'
                  : 'Continue with Facebook'}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-slate-400 text-[11px]">
            <div className="flex-1 h-px bg-slate-200" />
            <span>{language === 'np' ? 'वा इमेलबाट लगइन गर्नुहोस्' : 'or with email'}</span>
            <div className="flex-1 h-px bg-slate-200" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
            {/* Name (Sign up only) */}
            {mode === 'signup' && (
              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Full Legal Name (पुरा नाम) *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aayush Sharma"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Email Address (इमेल ठेगाना) *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  placeholder="name@gmail.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="font-semibold text-slate-700 block mb-1">
                Password (गोप्य कोड) *
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>

            {/* Phone & Campus (Sign up only) */}
            {mode === 'signup' && (
              <>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Nepali Mobile Phone (OTP प्रमाणीकरण)
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="+977 98XXXXXXXX"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                {role === 'renter' && (
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">
                      Campus / University in Nepal
                    </label>
                    <div className="relative">
                      <School className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="e.g. Tribhuvan University, Pulchowk IOE..."
                        value={university}
                        onChange={e => setUniversity(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loadingProvider !== null}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-60"
            >
              {loadingProvider === 'email' ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Authenticating with Firebase...</span>
                </div>
              ) : mode === 'signup' ? (
                <>
                  <span>Create Account & Start Renting</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>Sign In to My Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Login Shortcuts */}
          <div className="pt-3 border-t border-slate-100">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block mb-2 text-center">
              Quick 1-Click Demo Profiles:
            </span>
            <div className="grid grid-cols-3 gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => handleQuickDemo('renter')}
                className="py-1.5 px-2 bg-emerald-50 text-emerald-800 rounded-lg border border-emerald-200 font-semibold hover:bg-emerald-100 transition truncate"
              >
                🎓 Student
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('owner')}
                className="py-1.5 px-2 bg-blue-50 text-blue-800 rounded-lg border border-blue-200 font-semibold hover:bg-blue-100 transition truncate"
              >
                🏠 Landlord
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('admin')}
                className="py-1.5 px-2 bg-purple-50 text-purple-800 rounded-lg border border-purple-200 font-semibold hover:bg-purple-100 transition truncate"
              >
                🛡️ Admin
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
