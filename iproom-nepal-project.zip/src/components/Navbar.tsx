import React, { useState } from 'react';
import { Language, UserRole, UserProfile } from '../types';
import { getTranslation } from '../data/translations';
import { NotificationCenter } from './NotificationCenter';
import { AppNotification } from '../services/fcmService';
import {
  Home,
  Heart,
  Scale,
  PlusCircle,
  ShieldCheck,
  UserCheck,
  Languages,
  LogIn,
  LogOut,
  UserPlus,
  ChevronDown
} from 'lucide-react';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  activeRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  activeTab: 'browse' | 'map' | 'roommates' | 'guide' | 'owner-dashboard' | 'admin-dashboard';
  setActiveTab: (tab: 'browse' | 'map' | 'roommates' | 'guide' | 'owner-dashboard' | 'admin-dashboard') => void;
  wishlistCount: number;
  onOpenWishlist: () => void;
  compareCount: number;
  onOpenCompare: () => void;
  onOpenAddListing: () => void;
  currentUser: UserProfile | null;
  onOpenAuthModal: (mode?: 'login' | 'signup', role?: UserRole) => void;
  onSignOut: () => void;
  notifications?: AppNotification[];
  onOpenBookingContract?: (bookingId: string) => void;
  onOpenChatWithRoom?: (roomId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  activeRole,
  onRoleChange,
  activeTab,
  setActiveTab,
  wishlistCount,
  onOpenWishlist,
  compareCount,
  onOpenCompare,
  onOpenAddListing,
  currentUser,
  onOpenAuthModal,
  onSignOut,
  notifications = [],
  onOpenBookingContract,
  onOpenChatWithRoom,
}) => {
  const t = getTranslation(language);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-colors">
      {/* Top utility & authentication bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Target Role Selector Buttons (Selected Elements 1, 2, 3) */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">
              {currentUser ? 'Active Role:' : t.switchRole}
            </span>
            <div className="inline-flex rounded bg-slate-800 p-0.5 border border-slate-700">
              <button
                type="button"
                onClick={() => {
                  onRoleChange('renter');
                  if (!currentUser) {
                    onOpenAuthModal('login', 'renter');
                  }
                }}
                className={`px-2.5 py-0.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                  activeRole === 'renter'
                    ? 'bg-emerald-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
                title={currentUser ? 'Student Account Active' : 'Sign in as Student'}
              >
                <span>🎓 {t.roleStudent}</span>
                {currentUser && activeRole === 'renter' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  onRoleChange('owner');
                  setActiveTab('owner-dashboard');
                  if (!currentUser) {
                    onOpenAuthModal('login', 'owner');
                  }
                }}
                className={`px-2.5 py-0.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                  activeRole === 'owner'
                    ? 'bg-blue-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
                title={currentUser ? 'Owner Account Active' : 'Sign in as Room Owner'}
              >
                <span>🏠 {t.roleOwner}</span>
                {currentUser && activeRole === 'owner' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-300 animate-pulse" />
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  onRoleChange('admin');
                  setActiveTab('admin-dashboard');
                  if (!currentUser) {
                    onOpenAuthModal('login', 'admin');
                  }
                }}
                className={`px-2.5 py-0.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                  activeRole === 'admin'
                    ? 'bg-purple-600 text-white shadow-xs font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
                title={currentUser ? 'Admin Account Active' : 'Sign in as Administrator'}
              >
                <span>🛡️ {t.roleAdmin}</span>
                {currentUser && activeRole === 'admin' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-300 animate-pulse" />
                )}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            {/* Auth status indicator */}
            <div className="flex items-center gap-2">
              {currentUser ? (
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/80">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span className="truncate max-w-[130px] sm:max-w-[180px]">
                    {currentUser.name}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => onOpenAuthModal('login')}
                    className="text-slate-300 hover:text-white font-medium hover:underline flex items-center gap-1"
                  >
                    <LogIn className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'np' ? 'लगइन' : 'Sign In'}</span>
                  </button>
                  <span className="text-slate-600">·</span>
                  <button
                    type="button"
                    onClick={() => onOpenAuthModal('signup')}
                    className="text-emerald-400 hover:text-emerald-300 font-semibold hover:underline flex items-center gap-1"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{language === 'np' ? 'दर्ता गर्नुहोस्' : 'Sign Up'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Language toggle */}
            <div className="flex items-center gap-1 border-l border-slate-700 pl-3">
              <Languages className="w-3.5 h-3.5 text-slate-400" />
              <button
                type="button"
                onClick={() => onLanguageChange('en')}
                className={`px-1.5 py-0.5 rounded text-xs transition-colors ${
                  language === 'en' ? 'font-bold text-white bg-slate-800' : 'text-slate-400 hover:text-white'
                }`}
              >
                EN
              </button>
              <span className="text-slate-600">/</span>
              <button
                type="button"
                onClick={() => onLanguageChange('np')}
                className={`px-1.5 py-0.5 rounded text-xs transition-colors ${
                  language === 'np' ? 'font-bold text-emerald-400 bg-slate-800' : 'text-slate-400 hover:text-white'
                }`}
              >
                नेपाली
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Top Bar Contract: Zone 1 (Brand) - Zone 2 (Nav Links) - Zone 3 (Actions) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setActiveTab('browse')}
            className="flex items-center gap-2.5 text-left group"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-black text-lg tracking-tight shadow-sm group-hover:bg-emerald-800 transition-colors">
              IP
            </div>
            <div>
              <span className="font-display font-extrabold text-xl text-slate-900 tracking-tight block leading-tight">
                IP Room
              </span>
              <span className="text-[11px] text-slate-500 font-medium block leading-tight">
                {language === 'np' ? 'नेपालको कोठा बजार' : "Nepal's Room Finder"}
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={() => setActiveTab('browse')}
            className={`transition-colors hover:text-slate-900 pb-1 ${
              activeTab === 'browse' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' : ''
            }`}
          >
            {t.browseRooms}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('map')}
            className={`transition-colors hover:text-slate-900 pb-1 ${
              activeTab === 'map' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' : ''
            }`}
          >
            {t.mapView}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('roommates')}
            className={`transition-colors hover:text-slate-900 pb-1 ${
              activeTab === 'roommates' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' : ''
            }`}
          >
            {language === 'np' ? 'साथी खोज्नुहोस्' : 'Roommate Finder'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('guide')}
            className={`transition-colors hover:text-slate-900 pb-1 ${
              activeTab === 'guide' ? 'text-emerald-700 font-semibold border-b-2 border-emerald-600' : ''
            }`}
          >
            {language === 'np' ? 'विद्यार्थी निर्देशिका' : 'Student Guide'}
          </button>
          {activeRole === 'owner' && (
            <button
              type="button"
              onClick={() => setActiveTab('owner-dashboard')}
              className={`transition-colors hover:text-slate-900 pb-1 ${
                activeTab === 'owner-dashboard' ? 'text-blue-700 font-semibold border-b-2 border-blue-600' : ''
              }`}
            >
              {t.ownerDashboard}
            </button>
          )}
          {activeRole === 'admin' && (
            <button
              type="button"
              onClick={() => setActiveTab('admin-dashboard')}
              className={`transition-colors hover:text-slate-900 pb-1 ${
                activeTab === 'admin-dashboard' ? 'text-purple-700 font-semibold border-b-2 border-purple-600' : ''
              }`}
            >
              {t.adminDashboard}
            </button>
          )}
        </nav>

        {/* Zone 3: 1-2 primary actions & User Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Real-time Push Notification Center (FCM) */}
          <NotificationCenter
            currentUser={currentUser}
            activeRole={activeRole}
            language={language}
            notifications={notifications}
            onOpenBookingContract={onOpenBookingContract}
            onOpenOwnerDashboard={() => setActiveTab('owner-dashboard')}
            onOpenChatWithRoom={onOpenChatWithRoom}
          />

          {/* Wishlist toggle */}
          <button
            type="button"
            onClick={onOpenWishlist}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            title={t.savedWishlist}
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Compare toggle */}
          <button
            type="button"
            onClick={onOpenCompare}
            className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            title={t.compare}
            aria-label="Compare"
          >
            <Scale className="w-5 h-5" />
            {compareCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {compareCount}
              </span>
            )}
          </button>

          {/* Primary CTA: List Room */}
          <button
            type="button"
            onClick={onOpenAddListing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-all shadow-xs whitespace-nowrap active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">{t.listYourRoom}</span>
            <span className="sm:hidden">+ Room</span>
          </button>

          {/* Auth Button or User Profile Dropdown */}
          {currentUser ? (
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-1.5 p-1 rounded-full hover:bg-slate-100 transition border border-slate-200"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-full object-cover"
                />
                <ChevronDown className="w-3.5 h-3.5 text-slate-500 mr-1" />
              </button>

              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs animate-in fade-in slide-in-from-top-2">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-900 truncate">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                    <span className="inline-block mt-1 text-[10px] bg-emerald-50 text-emerald-700 font-semibold px-1.5 py-0.5 rounded capitalize">
                      {currentUser.role}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      if (currentUser.role === 'owner') setActiveTab('owner-dashboard');
                      else if (currentUser.role === 'admin') setActiveTab('admin-dashboard');
                      else setActiveTab('browse');
                    }}
                    className="w-full text-left px-4 py-2 text-slate-700 hover:bg-slate-50 transition"
                  >
                    My Dashboard
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      onSignOut();
                    }}
                    className="w-full text-left px-4 py-2 text-rose-600 hover:bg-rose-50 transition flex items-center gap-1.5 border-t border-slate-100 mt-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onOpenAuthModal('login')}
              className="px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition whitespace-nowrap"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

