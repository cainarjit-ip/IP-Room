/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  RoomListing,
  BookingRequest,
  DisputeTicket,
  Language,
  UserRole,
  OccupancyPreference,
  UserBehaviorProfile,
  UserProfile,
} from './types';
import { INITIAL_ROOMS, INITIAL_DISPUTES } from './data/mockRooms';
import { getTranslation } from './data/translations';
import {
  getInitialBehaviorProfile,
  trackRoomView,
  trackWishlistAction,
  trackBookingAction,
  trackSearchAction,
  calculateRecommendations,
} from './services/recommendationEngine';
import {
  auth,
  logoutUser,
  getUserProfile,
  subscribeToUserProfile,
  getStoredUserSession,
  saveUserSession,
} from './services/firebase';
import {
  AppNotification,
  subscribeToRealtimeNotifications,
  setupForegroundFCMListener,
  notifyOwnerOfNewBookingInquiry,
  notifyStudentOfBookingConfirmed,
} from './services/fcmService';
import { onAuthStateChanged } from 'firebase/auth';

// Components
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { HeroSearch } from './components/HeroSearch';
import { RoomCard } from './components/RoomCard';
import { RoomFilters } from './components/RoomFilters';
import { RoomDetailModal } from './components/RoomDetailModal';
import { InteractiveMapModal } from './components/InteractiveMapModal';
import { BookingPaymentModal } from './components/BookingPaymentModal';
import { DigitalLeaseAgreementModal } from './components/DigitalLeaseAgreementModal';
import { ChatDrawer } from './components/ChatDrawer';
import { CompareDrawer } from './components/CompareDrawer';
import { OwnerListingWizard } from './components/OwnerListingWizard';
import { OwnerDashboard } from './components/OwnerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { TenantGuideSection } from './components/TenantGuideSection';
import { RoommateFinder } from './components/RoommateFinder';
import { AIRecommendationsSection } from './components/AIRecommendationsSection';
import { WishlistModal } from './components/WishlistModal';
import { Footer } from './components/Footer';

// Icons
import {
  Sparkles,
  MapPin,
  Building,
  RotateCcw,
  SlidersHorizontal,
  Home,
  CheckCircle2,
  Users
} from 'lucide-react';

export default function App() {
  // Localization & Role states
  const [language, setLanguage] = useState<Language>('en');
  const [activeRole, setActiveRole] = useState<UserRole>('renter');
  const [activeTab, setActiveTab] = useState<
    'browse' | 'map' | 'roommates' | 'guide' | 'owner-dashboard' | 'admin-dashboard'
  >('browse');

  // Firebase User Authentication state (persisted across page reloads)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const cached = getStoredUserSession();
    if (cached) return cached;
    return {
      id: 'usr-student-demo',
      name: 'Aayush Sharma (Student)',
      email: 'aayush.sharma@gmail.com',
      phone: '+977 9841998877',
      role: 'renter',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
      verified: true,
      university: 'Tribhuvan University (Central Campus)',
      studentIdVerified: true,
    };
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [authModalRole, setAuthModalRole] = useState<UserRole>('renter');

  // Listen to Firebase auth state changes and synchronize Firestore profile
  useEffect(() => {
    let profileUnsubscribe: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async fbUser => {
      // Clean up previous real-time listener if user switches
      if (profileUnsubscribe) {
        profileUnsubscribe();
        profileUnsubscribe = null;
      }

      if (fbUser) {
        // 1. Initial direct fetch from Firestore
        try {
          const storedProfile = await getUserProfile(fbUser.uid);
          if (storedProfile) {
            saveUserSession(storedProfile);
            setCurrentUser(storedProfile);
            setActiveRole(storedProfile.role);
          } else {
            // If the document is still in flight from social OAuth, initialize with verified defaults
            const socialProfile: UserProfile = {
              id: fbUser.uid,
              name: fbUser.displayName || 'IP Room User',
              email: fbUser.email || '',
              phone: fbUser.phoneNumber || '+977 98XXXXXXXX',
              role: activeRole,
              avatar: fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
              verified: true,
              citizenshipVerified: activeRole === 'owner',
              university: activeRole === 'renter' ? 'Tribhuvan University (Central Campus)' : undefined,
              studentIdVerified: activeRole === 'renter',
            };
            saveUserSession(socialProfile);
            setCurrentUser(socialProfile);
          }
        } catch (e) {
          console.warn('Error synchronizing user profile on auth change:', e);
        }

        // 2. Attach real-time Firestore listener to keep role, verification status, and profile updates synchronized
        profileUnsubscribe = subscribeToUserProfile(fbUser.uid, syncedProfile => {
          saveUserSession(syncedProfile);
          setCurrentUser(syncedProfile);
          setActiveRole(syncedProfile.role);
        });
      } else {
        // Fallback to cached session if available, else retain current state or demo
        const cached = getStoredUserSession();
        if (cached) {
          setCurrentUser(cached);
          setActiveRole(cached.role);
        }
      }
    });

    return () => {
      unsubscribeAuth();
      if (profileUnsubscribe) {
        profileUnsubscribe();
      }
    };
  }, []);

  const handleOpenAuthModal = (mode: 'login' | 'signup' = 'login', role: UserRole = activeRole) => {
    setAuthModalMode(mode);
    setAuthModalRole(role);
    setIsAuthModalOpen(true);
  };

  const handleAuthSuccess = (profile: UserProfile) => {
    saveUserSession(profile);
    setCurrentUser(profile);
    setActiveRole(profile.role);
    if (profile.role === 'owner') {
      setActiveTab('owner-dashboard');
    } else if (profile.role === 'admin') {
      setActiveTab('admin-dashboard');
    }
  };

  const handleSignOut = async () => {
    saveUserSession(null);
    await logoutUser();
    setCurrentUser(null);
  };

  const t = getTranslation(language);

  // Data states
  const [rooms, setRooms] = useState<RoomListing[]>(INITIAL_ROOMS);
  const [bookings, setBookings] = useState<BookingRequest[]>([
    {
      id: 'BK-108291',
      roomId: 'room-ktm-01',
      roomTitle: 'Sunny Studio Flat with Study Desk & Fast WiFi near TU Gate',
      roomAddress: 'Nayabazar Ward 2, Kirtipur, Kathmandu',
      roomPrice: 8500,
      roomImage: INITIAL_ROOMS[0].images[0],
      tenantId: 'user-std-01',
      tenantName: 'Suman Gautam',
      tenantPhone: '+977 9841887722',
      tenantEmail: 'suman.physics@gmail.com',
      tenantUniversity: 'TU Central Dept of Physics',
      ownerId: 'owner-01',
      moveInDate: '2026-10-01',
      durationMonths: 6,
      totalMonthlyRent: 8075,
      securityDeposit: 8500,
      totalPaid: 16575,
      paymentMethod: 'khalti',
      paymentRefId: 'TXN-KHALTI-991823',
      status: 'confirmed',
      contractGenerated: true,
      createdAt: '2026-09-22',
    }
  ]);
  const [disputes, setDisputes] = useState<DisputeTicket[]>(INITIAL_DISPUTES);

  // Real-time Push Notifications (Firebase Cloud Messaging + Firestore)
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'notif-welcome',
      toUserId: 'all',
      toRole: 'all',
      type: 'system',
      title: 'Welcome to IP Room Nepal 🇳🇵',
      body: 'Real-time push alerts enabled for student bookings, owner approvals, and inquiries.',
      read: false,
      createdAt: new Date().toISOString(),
    }
  ]);

  // Subscribe to real-time FCM & Firestore push notifications
  useEffect(() => {
    const unsubscribeFirestore = subscribeToRealtimeNotifications(
      activeRole,
      currentUser?.id,
      incomingNotifs => {
        if (incomingNotifs.length > 0) {
          setNotifications(incomingNotifs);
        }
      }
    );

    let unsubscribeFCM: (() => void) | null = null;
    setupForegroundFCMListener(fcmNotif => {
      setNotifications(prev => [fcmNotif, ...prev.filter(n => n.id !== fcmNotif.id)]);
    }).then(unsub => {
      if (unsub) unsubscribeFCM = unsub;
    });

    return () => {
      unsubscribeFirestore();
      if (unsubscribeFCM) unsubscribeFCM();
    };
  }, [activeRole, currentUser?.id]);

  // Student user behavior & AI recommendation tracking
  const [userProfile, setUserProfile] = useState<UserBehaviorProfile>(getInitialBehaviorProfile());

  // Wishlist and Compare selections
  const [wishlistRoomIds, setWishlistRoomIds] = useState<string[]>(['room-ktm-01']);
  const [comparedRoomIds, setComparedRoomIds] = useState<string[]>([]);

  // Search & Filter state
  const [selectedProvince, setSelectedProvince] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedMunicipality, setSelectedMunicipality] = useState('');
  const [selectedRoomType, setSelectedRoomType] = useState('');
  const [selectedCampus, setSelectedCampus] = useState('Tribhuvan University (Central Campus)');
  const [maxBudget, setMaxBudget] = useState(25000);

  // Detailed Filter sidebar state
  const [filters, setFilters] = useState({
    roomType: '',
    occupancy: '' as OccupancyPreference | '',
    minPrice: 0,
    maxPrice: 25000,
    water24x7: false,
    solarHotWater: false,
    attachedBathroom: false,
    kitchenFacility: false,
    bikeParking: false,
    wifi: false,
    electricityBackup: false,
    verifiedOnly: false,
  });

  // Modals & Drawers state
  const [selectedRoomDetail, setSelectedRoomDetail] = useState<RoomListing | null>(null);
  const [bookingRoom, setBookingRoom] = useState<RoomListing | null>(null);
  const [viewingContractBooking, setViewingContractBooking] = useState<BookingRequest | null>(null);
  const [activeChatRoom, setActiveChatRoom] = useState<RoomListing | null>(null);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [isAddListingOpen, setIsAddListingOpen] = useState(false);

  // Track room view
  const handleSelectRoom = (room: RoomListing) => {
    setSelectedRoomDetail(room);
    const updated = trackRoomView(room.id, userProfile);
    setUserProfile(updated);
  };

  // Toggle wishlist
  const handleToggleWishlist = (roomId: string) => {
    const isCurrentlySaved = wishlistRoomIds.includes(roomId);
    const updatedWishlist = isCurrentlySaved
      ? wishlistRoomIds.filter(id => id !== roomId)
      : [...wishlistRoomIds, roomId];

    setWishlistRoomIds(updatedWishlist);
    const updatedProfile = trackWishlistAction(roomId, !isCurrentlySaved, userProfile);
    setUserProfile(updatedProfile);
  };

  // Toggle compare
  const handleToggleCompare = (roomId: string) => {
    if (comparedRoomIds.includes(roomId)) {
      setComparedRoomIds(prev => prev.filter(id => id !== roomId));
    } else {
      if (comparedRoomIds.length >= 3) {
        alert('You can compare a maximum of 3 rooms side-by-side.');
        return;
      }
      setComparedRoomIds(prev => [...prev, roomId]);
      setIsCompareOpen(true);
    }
  };

  // Quick book action
  const handleQuickBook = (room: RoomListing) => {
    setBookingRoom(room);
  };

  // Booking completion
  const handleBookingComplete = (newBooking: BookingRequest) => {
    setBookings(prev => [newBooking, ...prev]);
    const updatedProfile = trackBookingAction(newBooking.roomId, userProfile);
    setUserProfile(updatedProfile);
    setViewingContractBooking(newBooking);

    // Real-time FCM push notification to owner for new booking inquiry
    const targetRoom = rooms.find(r => r.id === newBooking.roomId);
    notifyOwnerOfNewBookingInquiry(
      targetRoom?.owner.id || newBooking.ownerId,
      newBooking
    );
  };

  // Search execution
  const handleSearchSubmit = () => {
    const updated = trackSearchAction(
      {
        campus: selectedCampus,
        location: selectedMunicipality || selectedDistrict || selectedProvince,
        maxBudget,
        roomType: selectedRoomType,
      },
      userProfile
    );
    setUserProfile(updated);
  };

  // Reset filters
  const handleResetFilters = () => {
    setSelectedProvince('');
    setSelectedDistrict('');
    setSelectedMunicipality('');
    setSelectedRoomType('');
    setSelectedCampus('');
    setMaxBudget(25000);
    setFilters({
      roomType: '',
      occupancy: '',
      minPrice: 0,
      maxPrice: 25000,
      water24x7: false,
      solarHotWater: false,
      attachedBathroom: false,
      kitchenFacility: false,
      bikeParking: false,
      wifi: false,
      electricityBackup: false,
      verifiedOnly: false,
    });
  };

  // Filtered rooms logic
  const filteredRooms = useMemo(() => {
    return rooms.filter(room => {
      // Province filter
      if (selectedProvince && room.location.province !== selectedProvince) return false;
      // District filter
      if (selectedDistrict && room.location.district !== selectedDistrict) return false;
      // Municipality filter
      if (selectedMunicipality && room.location.municipality !== selectedMunicipality) return false;
      // Campus filter
      if (selectedCampus && room.location.nearbyCampus !== selectedCampus) return false;
      // Room Type from hero
      if (selectedRoomType && room.roomType !== selectedRoomType) return false;
      // Budget from hero
      if (room.price > maxBudget) return false;

      // Sidebar Filter: Room type
      if (filters.roomType && room.roomType !== filters.roomType) return false;
      // Sidebar Filter: Occupancy
      if (filters.occupancy && room.occupancyPreference !== filters.occupancy) return false;
      // Sidebar Filter: Price
      if (room.price > filters.maxPrice) return false;
      // Amenities
      if (filters.water24x7 && !room.amenities.water24x7) return false;
      if (filters.solarHotWater && !room.amenities.hotWaterSolar) return false;
      if (filters.attachedBathroom && !room.amenities.attachedBathroom) return false;
      if (filters.kitchenFacility && !room.amenities.kitchenFacility) return false;
      if (filters.bikeParking && !room.amenities.bikeParking) return false;
      if (filters.wifi && !room.amenities.wifi) return false;
      if (filters.electricityBackup && !room.amenities.electricityBackup) return false;
      // Verified only
      if (filters.verifiedOnly && !room.owner.citizenshipVerified) return false;

      return true;
    });
  }, [
    rooms,
    selectedProvince,
    selectedDistrict,
    selectedMunicipality,
    selectedCampus,
    selectedRoomType,
    maxBudget,
    filters,
  ]);

  // AI Recommendations calculation
  const aiRecommendedRooms = useMemo(() => {
    return calculateRecommendations(rooms, userProfile);
  }, [rooms, userProfile]);

  // Wishlisted rooms objects
  const wishlistedRooms = useMemo(() => {
    return rooms.filter(r => wishlistRoomIds.includes(r.id));
  }, [rooms, wishlistRoomIds]);

  // Compared rooms objects
  const comparedRooms = useMemo(() => {
    return rooms.filter(r => comparedRoomIds.includes(r.id));
  }, [rooms, comparedRoomIds]);

  // Landlord: Add new listing
  const handleAddNewListing = (newRoom: RoomListing) => {
    setRooms(prev => [newRoom, ...prev]);
    setIsAddListingOpen(false);
    setActiveTab('browse');
    setSelectedRoomDetail(newRoom);
  };

  // Landlord: Accept booking request
  const handleAcceptBooking = (bookingId: string) => {
    setBookings(prev =>
      prev.map(b => (b.id === bookingId ? { ...b, status: 'confirmed' } : b))
    );
    const targetBooking = bookings.find(b => b.id === bookingId);
    if (targetBooking) {
      setViewingContractBooking(targetBooking);

      // Real-time FCM push notification to student that booking was confirmed
      notifyStudentOfBookingConfirmed(
        targetBooking.tenantId,
        targetBooking,
        currentUser?.name || 'Ram Bahadur Shrestha'
      );
    }
  };

  // Landlord: Reject booking request
  const handleRejectBooking = (bookingId: string) => {
    setBookings(prev => prev.filter(b => b.id !== bookingId));
  };

  // Admin: Approve listing
  const handleApproveRoom = (roomId: string) => {
    setRooms(prev =>
      prev.map(r => (r.id === roomId ? { ...r, status: 'active' } : r))
    );
  };

  // Admin: Reject listing
  const handleRejectRoom = (roomId: string) => {
    setRooms(prev => prev.filter(r => r.id !== roomId));
  };

  // Admin: Resolve dispute
  const handleResolveDispute = (disputeId: string, notes: string) => {
    setDisputes(prev =>
      prev.map(d =>
        d.id === disputeId
          ? { ...d, status: 'resolved', resolutionNotes: notes }
          : d
      )
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] text-slate-800 antialiased font-sans">
      {/* Top Bar Navigation */}
      <Navbar
        language={language}
        onLanguageChange={setLanguage}
        activeRole={activeRole}
        onRoleChange={setActiveRole}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        wishlistCount={wishlistRoomIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        compareCount={comparedRoomIds.length}
        onOpenCompare={() => setIsCompareOpen(true)}
        onOpenAddListing={() => setIsAddListingOpen(true)}
        currentUser={currentUser}
        onOpenAuthModal={handleOpenAuthModal}
        onSignOut={handleSignOut}
        notifications={notifications}
        onOpenBookingContract={bookingId => {
          const found = bookings.find(b => b.id === bookingId);
          if (found) {
            setViewingContractBooking(found);
          }
        }}
        onOpenChatWithRoom={roomId => {
          const found = rooms.find(r => r.id === roomId);
          if (found) {
            setActiveChatRoom(found);
          }
        }}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {activeTab === 'browse' && (
          <div className="space-y-8 pb-12">
            {/* Hero Search Section */}
            <HeroSearch
              language={language}
              selectedProvince={selectedProvince}
              onProvinceChange={setSelectedProvince}
              selectedDistrict={selectedDistrict}
              onDistrictChange={setSelectedDistrict}
              selectedMunicipality={selectedMunicipality}
              onMunicipalityChange={setSelectedMunicipality}
              selectedRoomType={selectedRoomType}
              onRoomTypeChange={setSelectedRoomType}
              selectedCampus={selectedCampus}
              onCampusSelect={camp => {
                setSelectedCampus(camp);
                if (camp) {
                  setUserProfile(prev => ({ ...prev, targetCampus: camp }));
                }
              }}
              maxBudget={maxBudget}
              onMaxBudgetChange={setMaxBudget}
              onSearch={handleSearchSubmit}
              totalRoomsCount={filteredRooms.length}
            />

            {/* AI Recommendation Engine Smart Strip (Top Matches for Student Profile) */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <AIRecommendationsSection
                recommendedRooms={aiRecommendedRooms}
                userProfile={userProfile}
                language={language}
                onSelectRoom={handleSelectRoom}
                onQuickBook={handleQuickBook}
                onAdjustPreferences={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </div>

            {/* Main Marketplace Grid: Filters Sidebar + Room Cards */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col lg:flex-row items-start gap-8">
                {/* Left: Filter Sidebar */}
                <div className="w-full lg:w-72 shrink-0">
                  <div className="sticky top-20">
                    <RoomFilters
                      language={language}
                      filters={filters}
                      onChange={updated => setFilters(prev => ({ ...prev, ...updated }))}
                      onReset={handleResetFilters}
                    />
                  </div>
                </div>

                {/* Right: Listings Stream */}
                <div className="flex-1 min-w-0 space-y-5 w-full">
                  {/* Result Header & Controls */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
                    <div>
                      <h2 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                        <span>Available Verified Rooms</span>
                        <span className="font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-xs">
                          {filteredRooms.length} Listings
                        </span>
                      </h2>
                      <span className="text-xs text-slate-500">
                        {selectedCampus ? `Filtered near ${selectedCampus}` : 'Across all Nepal municipalities'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setActiveTab('map')}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                      >
                        <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                        <span>View on Map</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveTab('roommates')}
                        className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition border border-emerald-200"
                      >
                        <Users className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Find Roommates</span>
                      </button>
                    </div>
                  </div>

                  {/* Listings Grid */}
                  {filteredRooms.length === 0 ? (
                    <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                      <Home className="w-12 h-12 text-slate-300 mx-auto" />
                      <h3 className="font-bold text-base text-slate-800">{t.noRoomsFound}</h3>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">{t.resetFilters}</p>
                      <button
                        type="button"
                        onClick={handleResetFilters}
                        className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition"
                      >
                        {t.clearFilters}
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                      {filteredRooms.map(room => (
                        <RoomCard
                          key={room.id}
                          room={room}
                          language={language}
                          isWishlisted={wishlistRoomIds.includes(room.id)}
                          onToggleWishlist={handleToggleWishlist}
                          isCompared={comparedRoomIds.includes(room.id)}
                          onToggleCompare={handleToggleCompare}
                          onSelectRoom={handleSelectRoom}
                          onQuickBook={handleQuickBook}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Interactive Map View Tab */}
        {activeTab === 'map' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <InteractiveMapModal
              rooms={rooms}
              language={language}
              onSelectRoom={handleSelectRoom}
              isEmbedded={true}
            />
          </div>
        )}

        {/* Roommate Finder Tab */}
        {activeTab === 'roommates' && (
          <RoommateFinder
            language={language}
            onOpenDirectChat={(name, role) => {
              // Open direct chat drawer
              const dummyRoom: RoomListing = {
                ...rooms[0],
                owner: {
                  ...rooms[0].owner,
                  name,
                }
              };
              setActiveChatRoom(dummyRoom);
            }}
          />
        )}

        {/* Student Guide Tab */}
        {activeTab === 'guide' && (
          <TenantGuideSection language={language} />
        )}

        {/* Owner Dashboard Tab */}
        {activeTab === 'owner-dashboard' && (
          <OwnerDashboard
            rooms={rooms}
            bookings={bookings}
            language={language}
            onOpenAddListing={() => setIsAddListingOpen(true)}
            onAcceptBooking={handleAcceptBooking}
            onRejectBooking={handleRejectBooking}
            onViewContract={b => setViewingContractBooking(b)}
            onSelectRoom={handleSelectRoom}
          />
        )}

        {/* Admin Dashboard Tab */}
        {activeTab === 'admin-dashboard' && (
          <AdminDashboard
            rooms={rooms}
            disputes={disputes}
            language={language}
            onApproveRoom={handleApproveRoom}
            onRejectRoom={handleRejectRoom}
            onResolveDispute={handleResolveDispute}
            onSelectRoom={handleSelectRoom}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        language={language}
        onNavigateTab={tab => setActiveTab(tab)}
      />

      {/* Modals & Overlays */}
      {/* 1. Room Detail Modal (Includes 360-Degree Interactive Virtual Tour) */}
      {selectedRoomDetail && (
        <RoomDetailModal
          room={selectedRoomDetail}
          language={language}
          onClose={() => setSelectedRoomDetail(null)}
          onStartBooking={room => {
            setSelectedRoomDetail(null);
            setBookingRoom(room);
          }}
          onOpenChat={room => {
            setActiveChatRoom(room);
          }}
        />
      )}

      {/* 2. Booking & Payment Modal (Khalti / eSewa / Card / Escrow) */}
      {bookingRoom && (
        <BookingPaymentModal
          room={bookingRoom}
          language={language}
          onClose={() => setBookingRoom(null)}
          onBookingComplete={handleBookingComplete}
        />
      )}

      {/* 3. Digital Tenancy Lease Agreement Modal (Nepal Muluki Civil Code 2074) */}
      {viewingContractBooking && (
        <DigitalLeaseAgreementModal
          booking={viewingContractBooking}
          room={rooms.find(r => r.id === viewingContractBooking.roomId)}
          language={language}
          onClose={() => setViewingContractBooking(null)}
        />
      )}

      {/* 4. Real-time In-App Chat Drawer */}
      {activeChatRoom && (
        <ChatDrawer
          room={activeChatRoom}
          language={language}
          onClose={() => setActiveChatRoom(null)}
        />
      )}

      {/* 5. Compare Drawer */}
      {isCompareOpen && (
        <CompareDrawer
          comparedRooms={comparedRooms}
          language={language}
          onRemoveRoom={id => setComparedRoomIds(prev => prev.filter(item => item !== id))}
          onClearAll={() => setComparedRoomIds([])}
          onSelectRoom={handleSelectRoom}
          onClose={() => setIsCompareOpen(false)}
        />
      )}

      {/* 6. Wishlist Modal */}
      {isWishlistOpen && (
        <WishlistModal
          wishlistRooms={wishlistedRooms}
          language={language}
          onRemove={handleToggleWishlist}
          onSelectRoom={handleSelectRoom}
          onClose={() => setIsWishlistOpen(false)}
        />
      )}

      {/* 7. Room Owner Listing Wizard */}
      {isAddListingOpen && (
        <OwnerListingWizard
          language={language}
          onClose={() => setIsAddListingOpen(false)}
          onSubmitNewRoom={handleAddNewListing}
        />
      )}

      {/* 8. Firebase Login & Sign Up Modal */}
      {isAuthModalOpen && (
        <AuthModal
          language={language}
          initialMode={authModalMode}
          initialRole={authModalRole}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={handleAuthSuccess}
        />
      )}
    </div>
  );
}
